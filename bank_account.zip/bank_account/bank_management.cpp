#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountHolder;
    double balance;

public:
    BankAccount(string name, double initialBalance) {
        accountHolder = name;
        balance = initialBalance;
    }

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Deposited: " << amount << "\n";
        } else {
            cout << "Invalid deposit amount.\n";
        }
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Withdrawn: " << amount << "\n";
        } else {
            cout << "Insufficient balance or invalid amount.\n";
        }
    }

    void showBalance() const {
        cout << "Current Balance: " << balance << "\n";
    }
};

int main() {
    string name;
    double initialBalance;

    cout << "=== Bank Management System ===\n";
    cout << "Enter account holder name: ";
    getline(cin, name);
    cout << "Enter initial balance: ";
    cin >> initialBalance;

    BankAccount account(name, initialBalance);

    int choice;
    do {
        cout << "\n1. Deposit\n2. Withdraw\n3. Show Balance\n4. Exit\nChoose an option: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                double amount;
                cout << "Enter deposit amount: ";
                cin >> amount;
                account.deposit(amount);
                break;
            }
            case 2: {
                double amount;
                cout << "Enter withdrawal amount: ";
                cin >> amount;
                account.withdraw(amount);
                break;
            }
            case 3:
                account.showBalance();
                break;
            case 4:
                cout << "Thank you for using our Bank Management System!\n";
                break;
            default:
                cout << "Invalid option. Try again.\n";
        }

    } while (choice != 4);

    return 0;
}
